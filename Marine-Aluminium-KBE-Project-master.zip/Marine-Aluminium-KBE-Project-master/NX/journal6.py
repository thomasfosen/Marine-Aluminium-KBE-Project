﻿# NX 12.0.2.9
# Journal created by andeslar on Thu Mar  5 14:58:00 2020 W. Europe Standard Time
#
import math
import NXOpen
import NXOpen.Assemblies
import NXOpen.CAE
import NXOpen.Fields
def main() : 

    theSession  = NXOpen.Session.GetSession()
    workFemPart = theSession.Parts.BaseWork
    displayFemPart = theSession.Parts.BaseDisplay
    
    
    fileNew1 = theSession.Parts.FileNew()
    
   
    
    fileNew1.TemplateFileName = "SimNxNastranMetric.sim"
    
    fileNew1.UseBlankTemplate = False
    
    fileNew1.ApplicationName = "CaeSimTemplate"
    
    fileNew1.Units = NXOpen.Part.Units.Millimeters
    
    fileNew1.RelationType = ""
    
    fileNew1.UsesMasterModel = "No"
    
    fileNew1.TemplateType = NXOpen.FileNewTemplateType.Item
    
    fileNew1.TemplatePresentationName = "NX Nastran"
    
    fileNew1.ItemType = ""
    
    fileNew1.Specialization = ""
    
    fileNew1.SetCanCreateAltrep(False)
    
    fileNew1.NewFileName = "C:\\Users\\andeslar\\KBE\\test2\\fem2_sim5.sim"
    
    fileNew1.MasterFileName = ""
    
    fileNew1.MakeDisplayedPart = True
    
    fileNew1.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    
   
    baseTemplateManager1 = theSession.XYPlotManager.TemplateManager
    

    workSimPart = theSession.Parts.BaseWork
    displaySimPart = theSession.Parts.BaseDisplay
  
    
    # ----------------------------------------------
    #   Dialog Begin New Simulation
    # ----------------------------------------------
  
    
    simPart1 = workSimPart
    femPart1 = theSession.Parts.FindObject("fem2")
    description1 = []
    simPart1.FinalizeCreation(femPart1, 0, description1)
    

    
    fileNew1.Destroy()
    
   
    
    simPart2 = workSimPart
    simSimulation1 = simPart2.Simulation
    
    simSolution1 = simSimulation1.CreateSolution("NX NASTRAN", "Structural", "SESTATIC 101 - Single Constraint", "Solution 1", NXOpen.CAE.SimSimulation.AxisymAbstractionType.NotSet)
    
 
    
    caePart1 = workSimPart
    modelingObjectPropertyTable1 = caePart1.ModelingObjectPropertyTables.CreateModelingObjectPropertyTable("Bulk Data Echo Request", "NX NASTRAN - Structural", "NX NASTRAN", "Bulk Data Echo Request1", 1)
    
    caePart2 = workSimPart
    modelingObjectPropertyTable2 = caePart2.ModelingObjectPropertyTables.CreateModelingObjectPropertyTable("Structural Output Requests", "NX NASTRAN - Structural", "NX NASTRAN", "Structural Output Requests1", 2)
    
  
    
    # ----------------------------------------------
    #   Dialog Begin Solution
    # ----------------------------------------------
   
    
    simSolution1.Rename("Solution 1", False)
    
    propertyTable2 = simSolution1.PropertyTable
    
    propertyTable2.SetBooleanPropertyValue("Iterative Solver", True)
    
    propertyTable2.SetNamedPropertyTablePropertyValue("Bulk Data Echo Request", modelingObjectPropertyTable1)
    
    propertyTable2.SetNamedPropertyTablePropertyValue("Output Requests", modelingObjectPropertyTable2)
    
    id1 = theSession.NewestVisibleUndoMark
    
    nErrs1 = theSession.UpdateManager.DoUpdate(id1)
    
    simSolutionStep1 = simSolution1.CreateStep(0, True, "Subcase - Static Loads 1")
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId10)
    
    
    
    theSession.SetUndoMarkName(id1, "Solution")
    
  
    
    simPart3 = workSimPart
    simSimulation2 = simPart3.Simulation
    
    simBCBuilder1 = simSimulation2.CreateBcBuilderForConstraintDescriptor("fixedConstraint", "Fixed(1)", 1)
    
    propertyTable3 = simBCBuilder1.PropertyTable
    
    setManager1 = simBCBuilder1.TargetSetManager
    
    fieldExpression1 = propertyTable3.GetScalarFieldPropertyValue("DOF1")
    
    fieldExpression2 = propertyTable3.GetScalarFieldPropertyValue("DOF2")
    
    fieldExpression3 = propertyTable3.GetScalarFieldPropertyValue("DOF3")
    
    fieldExpression4 = propertyTable3.GetScalarFieldPropertyValue("DOF4")
    
    fieldExpression5 = propertyTable3.GetScalarFieldPropertyValue("DOF5")
    
    fieldExpression6 = propertyTable3.GetScalarFieldPropertyValue("DOF6")

    
    # ----------------------------------------------
    #   Menu: Analysis->Solve...
    # ----------------------------------------------
  
    
   
    theSimSolveManager = NXOpen.CAE.SimSolveManager.GetSimSolveManager(theSession)
    
    psolutions1 = [NXOpen.CAE.SimSolution.Null] * 1 
    psolutions1[0] = simSolution1
    numsolutionssolved1, numsolutionsfailed1, numsolutionsskipped1 = theSimSolveManager.SolveChainOfSolutions(psolutions1, NXOpen.CAE.SimSolution.SolveOption.Solve, NXOpen.CAE.SimSolution.SetupCheckOption.CompleteCheckAndOutputErrors, NXOpen.CAE.SimSolution.SolveMode.Background)
    
    
    theSession.SetUndoMarkName(markId17, "Solve")
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()