﻿# NX 12.0.2.9
# Journal created by andeslar on Thu Mar  5 15:31:07 2020 W. Europe Standard Time
#
import math
import NXOpen
import NXOpen.CAE
def main() : 

    theSession  = NXOpen.Session.GetSession()
    workSimPart = theSession.Parts.BaseWork
    displaySimPart = theSession.Parts.BaseDisplay
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Make Displayed Part")
    
    femPart1 = theSession.Parts.FindObject("fem2")
    status1, partLoadStatus1 = theSession.Parts.SetActiveDisplay(femPart1, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.SameAsDisplay)
    
    workFemPart = theSession.Parts.BaseWork
    displayFemPart = theSession.Parts.BaseDisplay
    partLoadStatus1.Dispose()
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Make Displayed Part")
    
    simPart1 = theSession.Parts.FindObject("fem2_sim5")
    status2, partLoadStatus2 = theSession.Parts.SetActiveDisplay(simPart1, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.SameAsDisplay)
    
    workSimPart = theSession.Parts.BaseWork # fem2_sim5
    displaySimPart = theSession.Parts.BaseDisplay # fem2_sim5
    partLoadStatus2.Dispose()
    # ----------------------------------------------
    #   Menu: Analysis->Solve...
    # ----------------------------------------------
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    theSession.SetUndoMarkName(markId3, "Solve Dialog")
    
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Solve")
    
    theSession.DeleteUndoMark(markId4, None)
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Solve")
    
    theSimSolveManager = NXOpen.CAE.SimSolveManager.GetSimSolveManager(theSession)
    
    psolutions1 = [NXOpen.CAE.SimSolution.Null] * 1 
    simSimulation1 = workSimPart.FindObject("Simulation")
    simSolution1 = simSimulation1.FindObject("Solution[Solution 1]")
    psolutions1[0] = simSolution1
    numsolutionssolved1, numsolutionsfailed1, numsolutionsskipped1 = theSimSolveManager.SolveChainOfSolutions(psolutions1, NXOpen.CAE.SimSolution.SolveOption.Solve, NXOpen.CAE.SimSolution.SetupCheckOption.CompleteCheckAndOutputErrors, NXOpen.CAE.SimSolution.SolveMode.Background)
    
    theSession.DeleteUndoMark(markId5, None)
    
    theSession.SetUndoMarkName(markId3, "Solve")
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Make Displayed Part")
    
    status3, partLoadStatus3 = theSession.Parts.SetActiveDisplay(femPart1, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.SameAsDisplay)
    
    workFemPart = theSession.Parts.BaseWork # fem2
    displayFemPart = theSession.Parts.BaseDisplay # fem2
    partLoadStatus3.Dispose()
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Make Displayed Part")
    
    simPart2 = theSession.Parts.FindObject("fem2_sim1")
    status4, partLoadStatus4 = theSession.Parts.SetActiveDisplay(simPart2, NXOpen.DisplayPartOption.AllowAdditional, NXOpen.PartDisplayPartWorkPartOption.SameAsDisplay)
    
    workSimPart = theSession.Parts.BaseWork # fem2_sim1
    displaySimPart = theSession.Parts.BaseDisplay # fem2_sim1
    partLoadStatus4.Dispose()
    # ----------------------------------------------
    #   Menu: Analysis->Solve...
    # ----------------------------------------------
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    theSession.SetUndoMarkName(markId8, "Solve Dialog")
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Solve")
    
    theSession.DeleteUndoMark(markId9, None)
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Solve")
    
    psolutions2 = [NXOpen.CAE.SimSolution.Null] * 1 
    simSimulation2 = workSimPart.FindObject("Simulation")
    simSolution2 = simSimulation2.FindObject("Solution[Solution 1]")
    psolutions2[0] = simSolution2
    numsolutionssolved2, numsolutionsfailed2, numsolutionsskipped2 = theSimSolveManager.SolveChainOfSolutions(psolutions2, NXOpen.CAE.SimSolution.SolveOption.Solve, NXOpen.CAE.SimSolution.SetupCheckOption.CompleteCheckAndOutputErrors, NXOpen.CAE.SimSolution.SolveMode.Background)
    
    theSession.DeleteUndoMark(markId10, None)
    
    theSession.SetUndoMarkName(markId8, "Solve")
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()