﻿# NX 12.0.2.9
# Journal created by andeslar on Thu Mar  5 14:22:13 2020 W. Europe Standard Time
#
import math
import NXOpen
import NXOpen.CAE
def main() : 

    theSession  = NXOpen.Session.GetSession()
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    # ----------------------------------------------
    #   Menu: Application->Simulation->Pre/Post
    # ----------------------------------------------
 
    
    theSession.ApplicationSwitchImmediate("UG_APP_SFEM")
    workPart = theSession.Parts.Work # fem2_i
    displayPart = theSession.Parts.Display # fem2_i
    theSession.Parts.SetWork(workPart)
    
    femPart1 = theSession.Parts.FindObject("fem2")
    status2, partLoadStatus2 = theSession.Parts.SetDisplay(femPart1, False, True)
    
    workPart = NXOpen.Part.Null
    workFemPart = theSession.Parts.BaseWork
    displayPart = NXOpen.Part.Null
    displayFemPart = theSession.Parts.BaseDisplay
    femPart2 = workFemPart
    theSession.Parts.SetWork(femPart2)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()
	
